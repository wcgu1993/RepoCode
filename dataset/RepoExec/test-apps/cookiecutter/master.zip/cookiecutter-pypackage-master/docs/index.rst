.. cookiecutter-pypackage documentation master file, created by
   sphinx-quickstart on Sun Dec 13 09:13:01 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to cookiecutter-pypackage's documentation!
==================================================

Getting Started
---------------

.. toctree::
   :maxdepth: 2

   readme
   tutorial
   pypi_release_checklist

Basics
------

.. toctree::
   :maxdepth: 2

   prompts

Advanced Features
-----------------

.. toctree::
   :maxdepth: 2

   travis_pypi_setup
   console_script_setup


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
