=====
Usage
=====

To use {{ cookiecutter.project_name }} in a project::

    import {{ cookiecutter.project_slug }}
